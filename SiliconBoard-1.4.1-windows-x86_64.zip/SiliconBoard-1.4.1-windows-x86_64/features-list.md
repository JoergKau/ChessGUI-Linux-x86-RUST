# SiliconBoard — Features

SiliconBoard is a native UCI chess GUI for macOS (Apple Silicon), Linux and
Windows. The board sits on the left, the engine analysis on the right, and the
move list along the bottom — with a clean dark theme.

## Play and analyse

- Live analysis with **two UCI engines side by side** — evaluation, depth,
  nodes, speed and the principal variation in standard notation.
- **Play** against an engine as White or Black, or watch **engine vs
  engine**, with configurable time controls, increments and live clocks.
- **Play from a position**: paste a FEN and choose _Game → Start from
  here…_ — two engines play on with the current time control, and the PGN
  starts from that position.
- **Set up a position**: _Game → Setup board…_ opens a piece editor with a
  palette, side-to-move and castling controls, a FEN field and a live validity
  check. Apply the position on Close; Cancel leaves the game unchanged.
- Opening-book moves in games with any PolyGlot `.bin` book you load, plus a
  suggestions box named after the ECO opening.
- Resign, draw offers (accepted by the engine within a score margin),
  threefold-repetition claims, engine-vs-engine games that end themselves on
  threefold repetition or the fifty-move rule, and results written to the PGN.
- Robust engine handling: a file that is not a working UCI engine is
  explained, and an unresponsive engine is restarted automatically.

## PGN and FEN

- Open, save, and copy PGN and FEN.
- **Multi-game PGN browser**: a scrollable games list (White, Black, result,
  event, date) docked next to the analysis; click a game to load it.
- Mainline PGN comments are shown inline in the move list.
- Opens with a classic World Championship game selected.
- Player names from a loaded PGN are shown on the board's player bars.

## Engines and tournaments

- Load engine files directly (including launcher scripts — shell scripts on
  macOS and Linux, `.bat`/`.cmd`/`.ps1` files on Windows); an options
  dialog for every UCI option an engine declares. Each engine card's name is
  a pulldown of the known engines (loaded A/B and the engines used before,
  remembered across launches, the same list as the tournament window) with
  Browse… for another file.
- **Syzygy tablebases** via _Engine → Load tablebases…_: pick your
  tablebase folder(s) — 5-men and 6-men sets in separate folders are
  supported — and the path is given to every engine as its `SyzygyPath`
  option. _Engine → Tablebases in engines_ switches the configured path on
  or off without forgetting it.
- **Tournaments** on the main board: **Match** (two engines), **Round-Robin**
  (three engines, every pairing in both colours) and **Gauntlet** (engine 1
  against each of the other two). Time control, alternating colours, resign
  and draw adjudication, optional EPD/PolyGlot opening books, per-engine
  standings and a rating-difference line, and one PGN with every game.

## Chess databases

- **Create a database** from a PGN file, or open an existing `.sbd` file.
  Scid `.si4`/`.si5` collections can be converted on import.
- **Browse and filter** by player, rating, event, result, year and position;
  sort any column and scroll through the games. Double-click a game to load it
  on the board.
- **Housekeeping:** remove duplicates or empty games, add more PGN files,
  rebuild the position index and export the filtered selection back to PGN.
- Games are stored verbatim, so comments, variations, NAGs and unknown tags
  survive.

## Look and feel

- Board themes and piece sets; figurine piece symbols (`♘f6`) in the move
  list and the evaluation, and one best-move arrow per analysing engine.
- Everything — engines, engine options, time control, themes, window layout
  — is restored on the next launch.
- The About panel shows the version, project link and licence — from the
  application menu on macOS, or the toolbar's **ⓘ** button on Linux and
  Windows.

## Not (yet) included

- Variation trees and PGN variations; multi-PV engine lines;
  in-GUI tablebase probing (the engines do the probing).
